package context

const (
	// KubernetesEndpoint is the kubernetes endpoint name in a stored context
	KubernetesEndpoint = "kubernetes"
)
