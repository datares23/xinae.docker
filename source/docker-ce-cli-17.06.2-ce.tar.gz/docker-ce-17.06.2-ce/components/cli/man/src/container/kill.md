The main process inside each container specified will be sent SIGKILL,
 or any signal specified with option --signal.
