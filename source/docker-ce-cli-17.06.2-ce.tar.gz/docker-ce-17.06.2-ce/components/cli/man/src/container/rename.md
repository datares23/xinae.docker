Rename a container.  Container may be running, paused or stopped.
