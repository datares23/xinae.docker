
Alias for `docker container attach`.
