Alias for `docker container commit`.
