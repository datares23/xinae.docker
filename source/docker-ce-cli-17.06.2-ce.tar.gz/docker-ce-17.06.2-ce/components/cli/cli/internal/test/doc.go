// Package test is a test-only package that can be used by other cli package to write unit test.
//
// It as an internal package and cannot be used outside of github.com/docker/cli/cli package.
//
package test
