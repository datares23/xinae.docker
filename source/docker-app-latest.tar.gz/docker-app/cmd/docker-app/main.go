package main

import (
	"math/rand"
	"time"

	"github.com/docker/app/internal"
	app "github.com/docker/app/internal/commands"
	"github.com/docker/cli/cli-plugins/manager"
	"github.com/docker/cli/cli-plugins/plugin"
	"github.com/docker/cli/cli/command"
	"github.com/spf13/cobra"
)

func main() {
	rand.Seed(time.Now().UnixNano())
	plugin.Run(func(dockerCli command.Cli) *cobra.Command {
		cmd := app.NewRootCmd("app", dockerCli)
		originalPreRun := cmd.PersistentPreRunE
		cmd.PersistentPreRunE = func(cmd *cobra.Command, args []string) error {
			if err := plugin.PersistentPreRunE(cmd, args); err != nil {
				return err
			}
			if originalPreRun != nil {
				return originalPreRun(cmd, args)
			}
			return nil
		}
		return cmd
	}, manager.Metadata{
		SchemaVersion: "0.1.0",
		Vendor:        "Docker Inc.",
		Version:       internal.Version,
		Experimental:  true,
	})
}
