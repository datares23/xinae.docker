// +build testrunmain

package main

import "testing"

func TestRunMain(t *testing.T) {
	main()
}
