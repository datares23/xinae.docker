package internal

var (
	// MetadataVersion defines the current schema version
	MetadataVersion = "v0.2"
)
