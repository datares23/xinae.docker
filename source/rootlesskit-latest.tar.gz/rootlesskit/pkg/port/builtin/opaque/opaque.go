package opaque

const (
	SocketPath         = "builtin.socketpath"
	ChildReadyPipePath = "builtin.readypipepath"
)
